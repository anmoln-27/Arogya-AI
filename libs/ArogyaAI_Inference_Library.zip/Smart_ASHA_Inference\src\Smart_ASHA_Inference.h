#ifndef SMART_ASHA_INFERENCE_H
#define SMART_ASHA_INFERENCE_H

#include "edge-impulse-sdk/classifier/ei_run_classifier.h"

#endif // SMART_ASHA_INFERENCE_H
